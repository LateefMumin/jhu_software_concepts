from app import app, db

if __name__ == '__main__':
    with app.app_context():
        # Import models to ensure tables are created
        import models
        db.create_all()
        
        # Load sample data if tables are empty
        from models import Applicant
        if Applicant.query.count() == 0:
            from load_data import main as load_data_main
            load_data_main()
    
    app.run(host='0.0.0.0', port=5000, debug=True)
