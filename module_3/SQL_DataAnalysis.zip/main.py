#!/usr/bin/env python3
"""
Application Entry Point
Graduate School Data Analysis Platform

Author: Abdullateef Mumin
Simple entry point that launches the Flask web application.
Run this file to start the server and access the analysis dashboard.
"""
from app import app

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)