from app import db
from sqlalchemy import Integer, String, Text, Date, Float

class Applicant(db.Model):
    """Model for grad cafe applicant data"""
    __tablename__ = 'applicants'
    
    p_id = db.Column(Integer, primary_key=True)
    program = db.Column(Text, nullable=True)  # University and Department
    comments = db.Column(Text, nullable=True)  # Comments
    date_added = db.Column(Date, nullable=True)  # Date Added
    url = db.Column(Text, nullable=True)  # Link to Post on Grad Café
    status = db.Column(Text, nullable=True)  # Admission Status
    term = db.Column(Text, nullable=True)  # Start Term
    us_or_international = db.Column(Text, nullable=True)  # Student nationality
    gpa = db.Column(Float, nullable=True)  # Student GPA
    gre = db.Column(Float, nullable=True)  # Student GRE Quant
    gre_v = db.Column(Float, nullable=True)  # Student GRE Verbal
    gre_aw = db.Column(Float, nullable=True)  # Student Average Writing
    degree = db.Column(Text, nullable=True)  # Student Program Degree Type
    
    def __repr__(self):
        return f'<Applicant {self.p_id}: {self.program}>'
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'p_id': self.p_id,
            'program': self.program,
            'comments': self.comments,
            'date_added': self.date_added.isoformat() if self.date_added else None,
            'url': self.url,
            'status': self.status,
            'term': self.term,
            'us_or_international': self.us_or_international,
            'gpa': self.gpa,
            'gre': self.gre,
            'gre_v': self.gre_v,
            'gre_aw': self.gre_aw,
            'degree': self.degree
        }
