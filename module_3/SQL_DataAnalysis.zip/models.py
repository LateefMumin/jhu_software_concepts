#!/usr/bin/env python3
"""
Database Schema Definition
JHU EP 605.256 Module 3 Assignment

Defines the database model for graduate school applicant data following
the specified schema requirements. Uses SQLAlchemy ORM for clean database
abstraction and type safety.

Author: Abdullateef Mumin
The Applicant model captures all relevant information from grad cafe entries
including academic metrics, demographics, and admission outcomes.
"""
from app import db
from sqlalchemy import Integer, Text, Date, Float

class Applicant(db.Model):
    """Model for grad cafe applicant data with exact schema as specified"""
    __tablename__ = 'applicants'
    
    # Primary key and core fields
    p_id = db.Column(Integer, primary_key=True)
    program = db.Column(Text, nullable=True)  # University and Department
    comments = db.Column(Text, nullable=True)  # Comments
    date_added = db.Column(Date, nullable=True)  # Date Added
    url = db.Column(Text, nullable=True)  # Link to Post on Grad Café
    
    # Application status and term
    status = db.Column(Text, nullable=True)  # Admission Status
    term = db.Column(Text, nullable=True)  # Start Term
    
    # Demographics and academic metrics
    us_or_international = db.Column(Text, nullable=True)  # Student nationality
    gpa = db.Column(Float, nullable=True)  # Student GPA
    gre = db.Column(Float, nullable=True)  # Student GRE Quant
    gre_v = db.Column(Float, nullable=True)  # Student GRE Verbal
    gre_aw = db.Column(Float, nullable=True)  # Student Average Writing
    degree = db.Column(Text, nullable=True)  # Student Program Degree Type

    def __repr__(self):
        return f'<Applicant {self.p_id}: {self.program} - {self.status}>'

    def to_dict(self):
        """Convert model to dictionary for JSON serialization"""
        return {
            'p_id': self.p_id,
            'program': self.program,
            'comments': self.comments,
            'date_added': self.date_added.isoformat() if self.date_added else None,
            'url': self.url,
            'status': self.status,
            'term': self.term,
            'us_or_international': self.us_or_international,
            'gpa': float(self.gpa) if self.gpa else None,
            'gre': float(self.gre) if self.gre else None,
            'gre_v': float(self.gre_v) if self.gre_v else None,
            'gre_aw': float(self.gre_aw) if self.gre_aw else None,
            'degree': self.degree
        }