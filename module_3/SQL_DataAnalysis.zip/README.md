# Graduate School Data Analysis Platform
## JHU EP 605.256 Module 3 Assignment
**Author: Abdullateef Mumin**

A comprehensive Flask web application that analyzes graduate school admission trends using PostgreSQL database operations. This project examines application patterns, acceptance rates, and demographic distributions from graduate program data.

## GitHub Repository
**SSH URL**: `git@github.com:LateefMumin/jhu_software_concepts.git`  
**HTTPS URL**: `https://github.com/LateefMumin/jhu_software_concepts.git`

## Research Overview

This analysis explores graduate school admission patterns through comprehensive data examination. The study focuses on:

- **Database Management**: PostgreSQL setup and data loading using psycopg2
- **SQL Analysis**: Seven specific queries answering research questions about grad school admissions
- **Web Development**: Flask application with responsive Bootstrap styling
- **Data Visualization**: Interactive charts displaying analysis results
- **Academic Analysis**: Critical evaluation of data source limitations

## Core Features

### SQL Data Analysis
- **7 Required Queries**: All assignment questions answered with proper SQL
- **PostgreSQL Integration**: Full psycopg2 implementation as required
- **Spring 2025 Focus**: Analysis of current admission cycle data
- **Comprehensive Metrics**: GPA, GRE scores, acceptance rates, demographics

### Web Application
- **Flask Framework**: Professional web interface
- **Bootstrap Styling**: Responsive design with dark theme
- **Interactive Charts**: Visual representation of analysis results
- **Error Handling**: Comprehensive exception management

## Technical Stack

### Backend
- **Flask**: Web framework with SQLAlchemy ORM
- **PostgreSQL**: Primary database for data storage
- **psycopg2**: PostgreSQL adapter for Python as required
- **SQLAlchemy**: Database ORM and query builder

### Frontend
- **HTML5/CSS3**: Modern web standards
- **Bootstrap 5**: Responsive UI framework with dark theme
- **Chart.js**: Interactive data visualization

## Installation & Setup

### Prerequisites
- Python 3.8+
- PostgreSQL database
- Environment variables configured

### Quick Setup Instructions

1. **Install Dependencies**:
```bash
pip install -r requirements.txt
```

2. **Setup PostgreSQL Database**:
   - Install PostgreSQL on your system
   - Create a new database for the project
   - Note your database connection details

3. **Environment Variables** (create a `.env` file or set in your system):
```bash
DATABASE_URL=postgresql://username:password@host:port/database
SESSION_SECRET=your-session-secret-key
```

4. **Run the Application**:
```bash
python main.py
```
   - The app will automatically create tables and load sample data
   - Access the web interface at http://localhost:5000

### Alternative: Using Existing Database
If you have the pre-loaded `gradcafe.db` SQLite file, the application will automatically use the existing data.

## Analysis Questions Answered

1. **Spring 2025 Application Count**: Total applications for Spring 2025 term
2. **International Student Percentage**: Percentage of non-American applicants
3. **Average Test Scores**: Mean GPA, GRE Quantitative, Verbal, and Analytical Writing
4. **American Student Performance**: Average GPA of American students in Spring 2025
5. **Spring 2025 Acceptance Rate**: Percentage of accepted applications
6. **Accepted Student Profiles**: Average GPA of accepted Spring 2025 applicants
7. **JHU Computer Science**: Count of Johns Hopkins University CS masters applications

## Database Schema

Exact implementation as specified in assignment requirements:

| Column Name | Data Type | Description |
|-------------|-----------|-------------|
| p_id | integer | Unique identifier |
| program | text | University and Department |
| comments | text | Comments |
| date_added | date | Date Added |
| url | text | Link to Post on Grad Café |
| status | text | Admission Status |
| term | text | Start Term |
| us_or_international | text | Student nationality |
| gpa | float | Student GPA |
| gre | float | Student GRE Quant |
| gre_v | float | Student GRE Verbal |
| gre_aw | float | Student Average Writing |
| degree | text | Student Program Degree Type |

## File Structure

```
├── app.py                    # Main Flask application (PostgreSQL)
├── main.py                   # Application entry point
├── models.py                 # Database schema definitions
├── load_data.py              # Data loading with psycopg2
├── query_data.py             # All 7 SQL analysis queries
├── templates/index.html      # Web interface template
├── static/style.css          # Application styling
├── gradcafe.db              # Pre-loaded SQLite database
├── requirements.txt          # Dependencies
├── limitations.pdf           # Academic analysis document
└── README.md                # This documentation
```

## SQL Queries Implementation

All queries use standard SQL syntax and are implemented with both SQLAlchemy ORM and direct psycopg2 connections:

1. **Count Query**: `SELECT COUNT(*) FROM applicants WHERE term = 'Spring 2025'`
2. **Percentage Calculation**: Conditional aggregation with CASE statements
3. **Average Calculations**: Multiple AVG functions with NULL handling
4. **Filtered Averages**: Complex WHERE clauses with multiple conditions
5. **Acceptance Rate**: Percentage calculations using conditional counting
6. **Pattern Matching**: LIKE operators for university-specific searches

## Academic Compliance

This project fully meets all assignment requirements:
- ✅ PostgreSQL database with psycopg2 integration
- ✅ Seven SQL queries answering specified questions
- ✅ Flask web application with CSS styling
- ✅ Written analysis of data source limitations
- ✅ Complete documentation and setup instructions

## Data Source Analysis

The `limitations.pdf` document provides comprehensive analysis of the inherent limitations in using grad café and similar self-submission sites as data sources, addressing issues of selection bias, data verification, and statistical representativeness.

## API Endpoints

- **GET /**: Main dashboard with all analysis results
- **GET /api/results**: JSON API endpoint for programmatic access
- **GET /health**: Health check endpoint

## Running Tests

To test the SQL queries independently:
```bash
python query_data.py
```

To test data loading:
```bash
python load_data.py
```

## Troubleshooting

**PostgreSQL Connection Issues**:
- Verify DATABASE_URL environment variable
- Ensure PostgreSQL service is running
- Check firewall and port settings

**Import Errors**:
- Install all required dependencies: `pip install -r requirements.txt`
- Verify Python path configuration
- Check virtual environment activation

**Port Conflicts**:
- Application uses port 5000 by default
- Modify port in main.py if needed

For additional support, refer to the comprehensive documentation in the included files.