# Grad Café Data Analysis - JHU EP 605.256 Module 3

A Flask-based web application for analyzing grad school admission data scraped from Grad Café, implementing PostgreSQL database operations and presenting SQL query results through a styled web interface.

## GitHub Repository
**SSH URL**: `git@github.com:LateefMumin/jhu_software_concepts.git`  
**HTTPS URL**: `https://github.com/LateefMumin/jhu_software_concepts.git`

## Project Overview

This project fulfills the requirements for Module 3 of JHU EP 605.256 - Modern Software Concepts in Python. It demonstrates:

- **Database Management**: PostgreSQL setup and data loading using psycopg2
- **SQL Analysis**: Seven specific queries answering research questions about grad school admissions
- **Web Development**: Flask application with responsive Bootstrap styling
- **Data Visualization**: Interactive charts displaying analysis results
- **Academic Analysis**: Critical evaluation of data source limitations

## Features

### 🎯 Core Functionality
- **Data Loading**: Automated loading of grad café data into PostgreSQL
- **SQL Analytics**: Seven comprehensive queries analyzing admission patterns
- **Web Interface**: Professional Flask application with responsive design
- **Interactive Charts**: Visual representation of key statistics
- **Error Handling**: Comprehensive error management and user feedback

### 📊 Analysis Questions Answered
1. Spring 2025 application count
2. International student percentage
3. Average GPA, GRE, GRE V, GRE AW scores
4. American students' average GPA for Spring 2025
5. Spring 2025 acceptance rate
6. Average GPA of accepted Spring 2025 applicants
7. JHU Computer Science masters applications count

## Technical Stack

### Backend
- **Flask**: Web framework with SQLAlchemy ORM
- **PostgreSQL**: Primary database for data storage
- **psycopg2**: PostgreSQL adapter for Python
- **SQLAlchemy**: Database ORM and query builder

### Frontend
- **HTML5/CSS3**: Modern web standards
- **Bootstrap 5**: Responsive UI framework with dark theme
- **Chart.js**: Interactive data visualization
- **Font Awesome**: Professional iconography

### Data Processing
- **Pandas**: Data manipulation and analysis
- **JSON/CSV**: Multiple data format support
- **Python Standard Library**: Core functionality

## Installation & Setup

### Prerequisites
- Python 3.8+
- PostgreSQL database
- Environment variables configured

### Quick Setup Instructions

1. **Install Dependencies**:
```bash
pip install flask flask-sqlalchemy psycopg2-binary gunicorn sqlalchemy werkzeug email-validator
```

2. **Setup PostgreSQL Database**:
   - Install PostgreSQL on your system
   - Create a new database for the project
   - Note your database connection details

3. **Environment Variables** (create a `.env` file or set in your system):
```bash
DATABASE_URL=postgresql://username:password@host:port/database
SESSION_SECRET=your-session-secret-key
PGHOST=your-postgres-host
PGPORT=5432
PGDATABASE=your-database-name
PGUSER=your-username
PGPASSWORD=your-password
```

4. **Run the Application**:
```bash
python main.py
```
   - The app will automatically create tables and load sample data
   - Access the web interface at http://localhost:5000

### Alternative: Using Sample Data Only
If you don't want to set up PostgreSQL, you can modify the code to use SQLite:
- Change `DATABASE_URL` to `sqlite:///gradcafe.db`
- Remove psycopg2-binary dependency
