#!/usr/bin/env python3
"""
SQL Query Implementation for Graduate School Data Analysis
JHU EP 605.256 Module 3 Assignment

This module contains seven analytical SQL queries that examine graduate school
admission patterns, demographics, and academic performance metrics from the
grad cafe dataset. Each query addresses specific research questions about
Spring 2025 admissions.

Author: Abdullateef Mumin
Implementation uses PostgreSQL with SQLAlchemy ORM for database operations.
"""
import logging
from sqlalchemy import text, func
from app import app, db
from models import Applicant

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_spring_2025_entries():
    """
    Analysis Query 1: Count of Spring 2025 Applications
    
    Examines the total number of graduate school applications submitted for the
    Spring 2025 academic term across all programs and institutions.
    """
    try:
        with app.app_context():
            result = db.session.query(func.count(Applicant.p_id)).filter(
                Applicant.term == 'Spring 2025'
            ).scalar()
            
            return {
                'question': 'How many entries do you have in your database who have applied for Spring 2025?',
                'answer': result or 0,
                'sql_method': 'SQLAlchemy ORM with func.count()',
                'explanation': 'This query counts all applicant records where the term field equals "Spring 2025"'
            }
    except Exception as e:
        logger.error(f"Error in get_spring_2025_entries: {str(e)}")
        return {'error': str(e)}

def get_international_percentage():
    """
    Analysis Query 2: International Student Demographics
    
    Calculates the percentage of international students in the dataset.
    """
    try:
        with app.app_context():
            total_count = db.session.query(func.count(Applicant.p_id)).scalar()
            international_count = db.session.query(func.count(Applicant.p_id)).filter(
                Applicant.us_or_international == 'International'
            ).scalar()
            
            percentage = (international_count / total_count * 100) if total_count > 0 else 0
            
            return {
                'question': 'What percentage of entries are from international students?',
                'answer': round(percentage, 2),
                'breakdown': {
                    'total_applicants': total_count,
                    'international_applicants': international_count
                },
                'explanation': 'This query calculates the percentage of international students using conditional counting'
            }
    except Exception as e:
        logger.error(f"Error in get_international_percentage: {str(e)}")
        return {'error': str(e)}

def get_average_scores():
    """
    Analysis Query 3: Academic Performance Metrics
    
    Calculates average GPA, GRE Quantitative, GRE Verbal, and GRE Analytical Writing scores.
    """
    try:
        with app.app_context():
            # Query with proper null handling
            query = db.session.query(
                func.avg(Applicant.gpa).label('avg_gpa'),
                func.avg(Applicant.gre).label('avg_gre'),
                func.avg(Applicant.gre_v).label('avg_gre_v'),
                func.avg(Applicant.gre_aw).label('avg_gre_aw')
            ).filter(
                Applicant.gpa.isnot(None),
                Applicant.gre.isnot(None),
                Applicant.gre_v.isnot(None),
                Applicant.gre_aw.isnot(None)
            )
            
            result = query.first()
            
            return {
                'question': 'What is the average GPA, GRE, GRE V, GRE AW of applicants who provide these metrics?',
                'answer': {
                    'avg_gpa': round(float(result.avg_gpa), 2) if result.avg_gpa else 0,
                    'avg_gre': round(float(result.avg_gre), 2) if result.avg_gre else 0,
                    'avg_gre_v': round(float(result.avg_gre_v), 2) if result.avg_gre_v else 0,
                    'avg_gre_aw': round(float(result.avg_gre_aw), 2) if result.avg_gre_aw else 0
                },
                'explanation': 'This query calculates the average of each metric, excluding null values'
            }
    except Exception as e:
        logger.error(f"Error in get_average_scores: {str(e)}")
        return {'error': str(e)}

def get_american_spring_2025_gpa():
    """
    Analysis Query 4: American Student Academic Performance
    
    Calculates the average GPA of American students applying for Spring 2025.
    """
    try:
        with app.app_context():
            result = db.session.query(func.avg(Applicant.gpa)).filter(
                Applicant.us_or_international == 'American',
                Applicant.term == 'Spring 2025',
                Applicant.gpa.isnot(None)
            ).scalar()
            
            return {
                'question': 'What is the average GPA of American students in Spring 2025?',
                'answer': round(float(result), 2) if result else 0,
                'explanation': 'This query filters for American students in Spring 2025 and calculates their average GPA'
            }
    except Exception as e:
        logger.error(f"Error in get_american_spring_2025_gpa: {str(e)}")
        return {'error': str(e)}

def get_spring_2025_acceptance_rate():
    """
    Analysis Query 5: Spring 2025 Admission Success Rate
    
    Calculates the percentage of Spring 2025 applications that were accepted.
    """
    try:
        with app.app_context():
            total_spring_2025 = db.session.query(func.count(Applicant.p_id)).filter(
                Applicant.term == 'Spring 2025'
            ).scalar()
            
            accepted_spring_2025 = db.session.query(func.count(Applicant.p_id)).filter(
                Applicant.term == 'Spring 2025',
                Applicant.status == 'Accepted'
            ).scalar()
            
            percentage = (accepted_spring_2025 / total_spring_2025 * 100) if total_spring_2025 > 0 else 0
            
            return {
                'question': 'What percent of entries for Spring 2025 are Acceptances?',
                'answer': round(percentage, 2),
                'breakdown': {
                    'total_spring_2025': total_spring_2025,
                    'accepted_spring_2025': accepted_spring_2025
                },
                'explanation': 'This query calculates the acceptance rate for Spring 2025 applications'
            }
    except Exception as e:
        logger.error(f"Error in get_spring_2025_acceptance_rate: {str(e)}")
        return {'error': str(e)}

def get_accepted_spring_2025_gpa():
    """
    Analysis Query 6: Academic Profile of Accepted Students
    
    Calculates the average GPA of students accepted for Spring 2025.
    """
    try:
        with app.app_context():
            result = db.session.query(func.avg(Applicant.gpa)).filter(
                Applicant.term == 'Spring 2025',
                Applicant.status == 'Accepted',
                Applicant.gpa.isnot(None)
            ).scalar()
            
            return {
                'question': 'What is the average GPA of applicants who applied for Spring 2025 who are Acceptances?',
                'answer': round(float(result), 2) if result else 0,
                'explanation': 'This query calculates the average GPA for accepted Spring 2025 applicants'
            }
    except Exception as e:
        logger.error(f"Error in get_accepted_spring_2025_gpa: {str(e)}")
        return {'error': str(e)}

def get_jhu_cs_masters_count():
    """
    Analysis Query 7: Johns Hopkins Computer Science Applications
    
    Counts applications to Johns Hopkins University Computer Science masters programs.
    """
    try:
        with app.app_context():
            result = db.session.query(func.count(Applicant.p_id)).filter(
                Applicant.program.like('%Johns Hopkins University%'),
                Applicant.program.like('%Computer Science%'),
                Applicant.degree.in_(['MS', 'Master', 'Masters'])
            ).scalar()
            
            return {
                'question': 'How many entries are from applicants who applied to JHU for a masters degree in Computer Science?',
                'answer': result or 0,
                'explanation': 'This query uses pattern matching to find JHU Computer Science masters applications'
            }
    except Exception as e:
        logger.error(f"Error in get_jhu_cs_masters_count: {str(e)}")
        return {'error': str(e)}

def get_all_analysis_results():
    """
    Execute all analysis queries and return comprehensive results
    """
    try:
        # Execute all seven queries
        query_1 = get_spring_2025_entries()
        query_2 = get_international_percentage()
        query_3 = get_average_scores()
        query_4 = get_american_spring_2025_gpa()
        query_5 = get_spring_2025_acceptance_rate()
        query_6 = get_accepted_spring_2025_gpa()
        query_7 = get_jhu_cs_masters_count()
        
        # Compile summary results
        results = {
            'summary': {
                'spring_2025_count': query_1.get('answer', 0),
                'international_percentage': query_2.get('answer', 0),
                'average_scores': query_3.get('answer', {}),
                'american_spring_2025_gpa': query_4.get('answer', 0),
                'spring_2025_acceptance_rate': query_5.get('answer', 0),
                'accepted_spring_2025_gpa': query_6.get('answer', 0),
                'jhu_cs_masters_count': query_7.get('answer', 0)
            },
            'detailed_results': {
                'query_1': query_1,
                'query_2': query_2,
                'query_3': query_3,
                'query_4': query_4,
                'query_5': query_5,
                'query_6': query_6,
                'query_7': query_7
            }
        }
        
        logger.info("All analysis queries executed successfully")
        return results
        
    except Exception as e:
        logger.error(f"Error in get_all_analysis_results: {str(e)}")
        return {'error': str(e)}

def main():
    """
    Test function to run all queries independently
    """
    print("Graduate School Data Analysis - SQL Queries")
    print("=" * 55)
    print("Author: Abdullateef Mumin")
    print("Course: JHU EP 605.256 Module 3")
    print("=" * 55)
    
    queries = [
        ("Spring 2025 Applications", get_spring_2025_entries),
        ("International Student Percentage", get_international_percentage),
        ("Average Academic Scores", get_average_scores),
        ("American Spring 2025 GPA", get_american_spring_2025_gpa),
        ("Spring 2025 Acceptance Rate", get_spring_2025_acceptance_rate),
        ("Accepted Spring 2025 GPA", get_accepted_spring_2025_gpa),
        ("JHU CS Masters Count", get_jhu_cs_masters_count)
    ]
    
    for i, (name, query_func) in enumerate(queries, 1):
        print(f"\nQuery {i}: {name}")
        print("-" * 40)
        result = query_func()
        
        if 'error' not in result:
            print(f"Question: {result['question']}")
            print(f"Answer: {result['answer']}")
            if 'breakdown' in result:
                print(f"Details: {result['breakdown']}")
        else:
            print(f"Error: {result['error']}")

if __name__ == '__main__':
    main()