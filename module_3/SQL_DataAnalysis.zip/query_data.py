#!/usr/bin/env python3
"""
SQL Query Implementation for Graduate School Data Analysis
JHU EP 605.256 Module 3 Assignment

This module contains seven analytical SQL queries that examine graduate school
admission patterns, demographics, and academic performance metrics from the
grad cafe dataset. Each query addresses specific research questions about
Spring 2025 admissions.

Author: Abdullateef Mumin
Implementation uses PostgreSQL with SQLAlchemy ORM for database operations.
"""
import logging
from sqlalchemy import text
from app_corrected import app, db

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_spring_2025_entries():
    """
    Analysis Query 1: Count of Spring 2025 Applications
    
    Examines the total number of graduate school applications submitted for the
    Spring 2025 academic term across all programs and institutions.
    """
    try:
        with app.app_context():
            query_text = "SELECT COUNT(*) FROM applicants WHERE term = 'Spring 2025'"
            result = db.session.execute(text(query_text)).scalar()
            
            return {
                'question': 'How many entries do you have in your database who have applied for Spring 2025?',
                'answer': result or 0,
                'query': query_text,
                'explanation': 'This query counts all applicant records where the term field equals "Spring 2025"'
            }
    except Exception as e:
        logger.error(f"Error in get_spring_2025_entries: {str(e)}")
        return {'error': str(e)}

def get_international_percentage():
    """
    Query 2: What percentage of entries are from international students (not American or Other)?
    """
    try:
        with app.app_context():
            query_text = """
            SELECT 
                COUNT(CASE WHEN us_or_international = 'International' THEN 1 END) * 100.0 / COUNT(*) 
            FROM applicants
            """
            result = db.session.execute(text(query_text)).scalar()
            
            return {
                'question': 'What percentage of entries are from international students (not American or Other)?',
                'answer': round(float(result), 2) if result else 0,
                'query': query_text.strip(),
                'explanation': 'This query calculates the percentage of international students using conditional aggregation'
            }
    except Exception as e:
        logger.error(f"Error in get_international_percentage: {str(e)}")
        return {'error': str(e)}

def get_average_scores():
    """
    Query 3: What is the average GPA, GRE, GRE V, GRE AW of applicants who provide these metrics?
    """
    try:
        with app.app_context():
            query_text = """
            SELECT 
                AVG(gpa) as avg_gpa,
                AVG(gre) as avg_gre,
                AVG(gre_v) as avg_gre_v,
                AVG(gre_aw) as avg_gre_aw
            FROM applicants
            WHERE gpa IS NOT NULL 
                AND gre IS NOT NULL 
                AND gre_v IS NOT NULL 
                AND gre_aw IS NOT NULL
            """
            result = db.session.execute(text(query_text)).fetchone()
            
            if result:
                return {
                    'question': 'What is the average GPA, GRE, GRE V, GRE AW of applicants who provide these metrics?',
                    'answer': {
                        'avg_gpa': round(float(result[0]), 2) if result[0] else 0,
                        'avg_gre': round(float(result[1]), 2) if result[1] else 0,
                        'avg_gre_v': round(float(result[2]), 2) if result[2] else 0,
                        'avg_gre_aw': round(float(result[3]), 2) if result[3] else 0
                    },
                    'query': query_text.strip(),
                    'explanation': 'This query calculates the average of each metric, excluding null values'
                }
    except Exception as e:
        logger.error(f"Error in get_average_scores: {str(e)}")
        return {'error': str(e)}

def get_american_spring_2025_gpa():
    """
    Query 4: What is the average GPA of American students in Spring 2025?
    """
    try:
        with app.app_context():
            query_text = """
            SELECT AVG(gpa) 
            FROM applicants 
            WHERE us_or_international = 'American' 
                AND term = 'Spring 2025' 
                AND gpa IS NOT NULL
            """
            result = db.session.execute(text(query_text)).scalar()
            
            return {
                'question': 'What is the average GPA of American students in Spring 2025?',
                'answer': round(float(result), 2) if result else 0,
                'query': query_text.strip(),
                'explanation': 'This query filters for American students in Spring 2025 and calculates their average GPA'
            }
    except Exception as e:
        logger.error(f"Error in get_american_spring_2025_gpa: {str(e)}")
        return {'error': str(e)}

def get_spring_2025_acceptance_rate():
    """
    Query 5: What percent of entries for Spring 2025 are Acceptances?
    """
    try:
        with app.app_context():
            query_text = """
            SELECT 
                COUNT(CASE WHEN status = 'Accepted' THEN 1 END) * 100.0 / COUNT(*) 
            FROM applicants 
            WHERE term = 'Spring 2025'
            """
            result = db.session.execute(text(query_text)).scalar()
            
            return {
                'question': 'What percent of entries for Spring 2025 are Acceptances?',
                'answer': round(float(result), 2) if result else 0,
                'query': query_text.strip(),
                'explanation': 'This query calculates the acceptance rate for Spring 2025 applications'
            }
    except Exception as e:
        logger.error(f"Error in get_spring_2025_acceptance_rate: {str(e)}")
        return {'error': str(e)}

def get_accepted_spring_2025_gpa():
    """
    Query 6: What is the average GPA of applicants who applied for Spring 2025 who are Acceptances?
    """
    try:
        with app.app_context():
            query_text = """
            SELECT AVG(gpa) 
            FROM applicants 
            WHERE term = 'Spring 2025' 
                AND status = 'Accepted' 
                AND gpa IS NOT NULL
            """
            result = db.session.execute(text(query_text)).scalar()
            
            return {
                'question': 'What is the average GPA of applicants who applied for Spring 2025 who are Acceptances?',
                'answer': round(float(result), 2) if result else 0,
                'query': query_text.strip(),
                'explanation': 'This query calculates the average GPA for accepted Spring 2025 applicants'
            }
    except Exception as e:
        logger.error(f"Error in get_accepted_spring_2025_gpa: {str(e)}")
        return {'error': str(e)}

def get_jhu_cs_masters_count():
    """
    Query 7: How many entries are from applicants who applied to JHU for a masters degree in Computer Science?
    """
    try:
        with app.app_context():
            query_text = """
            SELECT COUNT(*) 
            FROM applicants 
            WHERE program LIKE '%Johns Hopkins University%Computer Science%' 
                AND (degree = 'MS' OR degree = 'Master' OR degree = 'Masters')
            """
            result = db.session.execute(text(query_text)).scalar()
            
            return {
                'question': 'How many entries are from applicants who applied to JHU for a masters degree in Computer Science?',
                'answer': result or 0,
                'query': query_text.strip(),
                'explanation': 'This query uses pattern matching to find JHU Computer Science masters applications'
            }
    except Exception as e:
        logger.error(f"Error in get_jhu_cs_masters_count: {str(e)}")
        return {'error': str(e)}

def get_all_analysis_results():
    """
    Get all analysis results for display
    """
    try:
        query_1 = get_spring_2025_entries()
        query_2 = get_international_percentage()
        query_3 = get_average_scores()
        query_4 = get_american_spring_2025_gpa()
        query_5 = get_spring_2025_acceptance_rate()
        query_6 = get_accepted_spring_2025_gpa()
        query_7 = get_jhu_cs_masters_count()
        
        results = {
            'spring_2025_count': query_1.get('answer', 0),
            'international_percentage': query_2.get('answer', 0),
            'average_scores': query_3.get('answer', {}),
            'american_spring_2025_gpa': query_4.get('answer', 0),
            'spring_2025_acceptance_rate': query_5.get('answer', 0),
            'accepted_spring_2025_gpa': query_6.get('answer', 0),
            'jhu_cs_masters_count': query_7.get('answer', 0),
            'detailed_results': {
                'query_1': query_1,
                'query_2': query_2,
                'query_3': query_3,
                'query_4': query_4,
                'query_5': query_5,
                'query_6': query_6,
                'query_7': query_7
            }
        }
        return results
    except Exception as e:
        logger.error(f"Error in get_all_analysis_results: {str(e)}")
        return {'error': str(e)}

def main():
    """
    Main function to test all queries
    """
    print("Running SQL Data Analysis Queries...")
    print("=" * 50)
    
    queries = [
        get_spring_2025_entries,
        get_international_percentage,
        get_average_scores,
        get_american_spring_2025_gpa,
        get_spring_2025_acceptance_rate,
        get_accepted_spring_2025_gpa,
        get_jhu_cs_masters_count
    ]
    
    for i, query_func in enumerate(queries, 1):
        result = query_func()
        print(f"\nQuery {i}:")
        if 'error' not in result:
            print(f"Question: {result['question']}")
            print(f"Answer: {result['answer']}")
            print(f"SQL: {result['query']}")
        else:
            print(f"Error: {result['error']}")

if __name__ == '__main__':
    main()