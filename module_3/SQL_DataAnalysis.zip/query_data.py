import os
import logging
from app import app, db
from models import Applicant
from sqlalchemy import func, text

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def get_spring_2025_entries():
    """
    Query 1: How many entries do you have in your database who have applied for Spring 2025?
    """
    try:
        with app.app_context():
            count = Applicant.query.filter(Applicant.term == 'Spring 2025').count()
            query_text = "SELECT COUNT(*) FROM applicants WHERE term = 'Spring 2025'"
            return {
                'question': 'How many entries do you have in your database who have applied for Spring 2025?',
                'answer': count,
                'query': query_text,
                'explanation': 'This query counts all records where the term field equals "Spring 2025"'
            }
    except Exception as e:
        logger.error(f"Error in get_spring_2025_entries: {str(e)}")
        return {'error': str(e)}

def get_international_percentage():
    """
    Query 2: What percentage of entries are from international students (not American or Other)?
    """
    try:
        with app.app_context():
            total_count = Applicant.query.count()
            international_count = Applicant.query.filter(Applicant.us_or_international == 'International').count()
            
            percentage = round((international_count / total_count) * 100, 2) if total_count > 0 else 0
            
            query_text = """
            SELECT 
                ROUND((COUNT(*) FILTER (WHERE us_or_international = 'International') * 100.0 / COUNT(*)), 2) as percentage
            FROM applicants
            """
            
            return {
                'question': 'What percentage of entries are from international students (not American or Other)?',
                'answer': f"{percentage}%",
                'query': query_text,
                'explanation': 'This query calculates the percentage of international students by dividing international count by total count'
            }
    except Exception as e:
        logger.error(f"Error in get_international_percentage: {str(e)}")
        return {'error': str(e)}

def get_average_scores():
    """
    Query 3: What is the average GPA, GRE, GRE V, GRE AW of applicants who provide these metrics?
    """
    try:
        with app.app_context():
            result = db.session.query(
                func.avg(Applicant.gpa).label('avg_gpa'),
                func.avg(Applicant.gre).label('avg_gre'),
                func.avg(Applicant.gre_v).label('avg_gre_v'),
                func.avg(Applicant.gre_aw).label('avg_gre_aw')
            ).first()
            
            query_text = """
            SELECT 
                AVG(gpa) as avg_gpa,
                AVG(gre) as avg_gre,
                AVG(gre_v) as avg_gre_v,
                AVG(gre_aw) as avg_gre_aw
            FROM applicants
            WHERE gpa IS NOT NULL OR gre IS NOT NULL OR gre_v IS NOT NULL OR gre_aw IS NOT NULL
            """
            
            return {
                'question': 'What is the average GPA, GRE, GRE V, GRE AW of applicants who provide these metrics?',
                'answer': {
                    'avg_gpa': round(float(result.avg_gpa), 2) if result.avg_gpa else 0,
                    'avg_gre': round(float(result.avg_gre), 2) if result.avg_gre else 0,
                    'avg_gre_v': round(float(result.avg_gre_v), 2) if result.avg_gre_v else 0,
                    'avg_gre_aw': round(float(result.avg_gre_aw), 2) if result.avg_gre_aw else 0
                },
                'query': query_text,
                'explanation': 'This query calculates the average of each metric, excluding null values'
            }
    except Exception as e:
        logger.error(f"Error in get_average_scores: {str(e)}")
        return {'error': str(e)}

def get_american_spring_2025_gpa():
    """
    Query 4: What is their average GPA of American students in Spring 2025?
    """
    try:
        with app.app_context():
            result = db.session.query(func.avg(Applicant.gpa)).filter(
                Applicant.term == 'Spring 2025',
                Applicant.us_or_international == 'American',
                Applicant.gpa.isnot(None)
            ).scalar()
            
            avg_gpa = round(float(result), 2) if result else 0
            
            query_text = """
            SELECT AVG(gpa) as avg_gpa
            FROM applicants
            WHERE term = 'Spring 2025' 
                AND us_or_international = 'American' 
                AND gpa IS NOT NULL
            """
            
            return {
                'question': 'What is the average GPA of American students in Spring 2025?',
                'answer': avg_gpa,
                'query': query_text,
                'explanation': 'This query calculates the average GPA for American students applying for Spring 2025'
            }
    except Exception as e:
        logger.error(f"Error in get_american_spring_2025_gpa: {str(e)}")
        return {'error': str(e)}

def get_spring_2025_acceptance_rate():
    """
    Query 5: What percent of entries for Spring 2025 are Acceptances?
    """
    try:
        with app.app_context():
            total_spring_2025 = Applicant.query.filter(Applicant.term == 'Spring 2025').count()
            accepted_spring_2025 = Applicant.query.filter(
                Applicant.term == 'Spring 2025',
                Applicant.status == 'Accepted'
            ).count()
            
            percentage = round((accepted_spring_2025 / total_spring_2025) * 100, 2) if total_spring_2025 > 0 else 0
            
            query_text = """
            SELECT 
                ROUND((COUNT(*) FILTER (WHERE status = 'Accepted') * 100.0 / COUNT(*)), 2) as acceptance_rate
            FROM applicants
            WHERE term = 'Spring 2025'
            """
            
            return {
                'question': 'What percent of entries for Spring 2025 are Acceptances?',
                'answer': f"{percentage}%",
                'query': query_text,
                'explanation': 'This query calculates the acceptance rate for Spring 2025 applications'
            }
    except Exception as e:
        logger.error(f"Error in get_spring_2025_acceptance_rate: {str(e)}")
        return {'error': str(e)}

def get_accepted_spring_2025_gpa():
    """
    Query 6: What is the average GPA of applicants who applied for Spring 2025 who are Acceptances?
    """
    try:
        with app.app_context():
            result = db.session.query(func.avg(Applicant.gpa)).filter(
                Applicant.term == 'Spring 2025',
                Applicant.status == 'Accepted',
                Applicant.gpa.isnot(None)
            ).scalar()
            
            avg_gpa = round(float(result), 2) if result else 0
            
            query_text = """
            SELECT AVG(gpa) as avg_gpa
            FROM applicants
            WHERE term = 'Spring 2025' 
                AND status = 'Accepted' 
                AND gpa IS NOT NULL
            """
            
            return {
                'question': 'What is the average GPA of applicants who applied for Spring 2025 who are Acceptances?',
                'answer': avg_gpa,
                'query': query_text,
                'explanation': 'This query calculates the average GPA for accepted Spring 2025 applicants'
            }
    except Exception as e:
        logger.error(f"Error in get_accepted_spring_2025_gpa: {str(e)}")
        return {'error': str(e)}

def get_jhu_cs_masters_count():
    """
    Query 7: How many entries are from applicants who applied to JHU for a masters degrees in Computer Science?
    """
    try:
        with app.app_context():
            count = Applicant.query.filter(
                Applicant.program.like('%Johns Hopkins%'),
                Applicant.program.like('%Computer Science%'),
                Applicant.degree.in_(['MS', 'Master', 'Masters'])
            ).count()
            
            query_text = """
            SELECT COUNT(*)
            FROM applicants
            WHERE program LIKE '%Johns Hopkins%'
                AND program LIKE '%Computer Science%'
                AND degree IN ('MS', 'Master', 'Masters')
            """
            
            return {
                'question': 'How many entries are from applicants who applied to JHU for a masters degrees in Computer Science?',
                'answer': count,
                'query': query_text,
                'explanation': 'This query counts entries for Johns Hopkins Computer Science masters programs'
            }
    except Exception as e:
        logger.error(f"Error in get_jhu_cs_masters_count: {str(e)}")
        return {'error': str(e)}

def get_all_analysis_results():
    """
    Get all analysis results for display
    """
    results = []
    
    # Execute all queries
    queries = [
        get_spring_2025_entries,
        get_international_percentage,
        get_average_scores,
        get_american_spring_2025_gpa,
        get_spring_2025_acceptance_rate,
        get_accepted_spring_2025_gpa,
        get_jhu_cs_masters_count
    ]
    
    for query_func in queries:
        try:
            result = query_func()
            results.append(result)
        except Exception as e:
            logger.error(f"Error executing query {query_func.__name__}: {str(e)}")
            results.append({
                'question': f'Error in {query_func.__name__}',
                'error': str(e)
            })
    
    return results

def main():
    """
    Main function to test all queries
    """
    print("Testing all SQL queries...")
    results = get_all_analysis_results()
    
    for i, result in enumerate(results, 1):
        print(f"\n--- Query {i} ---")
        if 'error' in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Question: {result['question']}")
            print(f"Answer: {result['answer']}")
            print(f"Query: {result['query']}")
            print(f"Explanation: {result['explanation']}")

if __name__ == '__main__':
    main()
