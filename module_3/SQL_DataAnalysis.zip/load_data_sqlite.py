#!/usr/bin/env python3
"""
Load large dataset into SQLite database for local development
"""
import random
from datetime import date, timedelta
import sqlite3
import os

def generate_realistic_data():
    """Generate realistic applicant data for SQLite"""
    # University programs
    programs = [
        "Stanford University - Computer Science", "MIT - Computer Science", "Carnegie Mellon University - Computer Science",
        "University of California Berkeley - Computer Science", "Harvard University - Computer Science", 
        "Princeton University - Computer Science", "Yale University - Computer Science", "Columbia University - Computer Science",
        "Cornell University - Computer Science", "University of Pennsylvania - Computer Science",
        "Johns Hopkins University - Computer Science", "Northwestern University - Computer Science",
        "Duke University - Computer Science", "University of Chicago - Computer Science", "Rice University - Computer Science",
        "University of Southern California - Computer Science", "University of California Los Angeles - Computer Science",
        "University of California San Diego - Computer Science", "Georgia Institute of Technology - Computer Science",
        "University of Illinois Urbana-Champaign - Computer Science", "University of Washington - Computer Science",
        "University of Texas Austin - Computer Science", "University of Michigan Ann Arbor - Computer Science",
        "Purdue University - Computer Science", "Ohio State University - Computer Science",
        "University of Wisconsin Madison - Computer Science", "University of Maryland College Park - Computer Science",
        "Stanford University - Data Science", "MIT - Data Science", "Harvard University - Data Science",
        "MIT - Electrical Engineering", "Stanford University - Electrical Engineering",
        "Harvard University - Mathematics", "MIT - Mathematics", "Princeton University - Mathematics",
        "Stanford University - Statistics", "University of California Berkeley - Statistics"
    ]
    
    comments = [
        "Great program with excellent research opportunities", "Strong faculty in my area of interest",
        "Excited about the research potential here", "This is my dream school", "Excellent fit for my research interests",
        "Strong program reputation", "Great location and facilities", "Looking forward to the opportunity",
        "Perfect match for my career goals", "Impressed by the faculty research", "Hoping for funding opportunities",
        "Strong alumni network", "Excellent research facilities", "Great program curriculum",
        "Perfect fit for my background", "Excited about potential collaborations"
    ]
    
    def weighted_choice(choices):
        total = sum(weight for choice, weight in choices)
        r = random.uniform(0, total)
        upto = 0
        for choice, weight in choices:
            if upto + weight >= r:
                return choice
            upto += weight
        return choices[-1][0]
    
    # Weighted distributions
    status_choices = [("Accepted", 0.35), ("Rejected", 0.55), ("Wait List", 0.08), ("Interview", 0.02)]
    term_choices = [("Spring 2025", 0.85), ("Fall 2024", 0.10), ("Spring 2024", 0.03), ("Fall 2025", 0.02)]
    nationality_choices = [("American", 0.48), ("International", 0.50), ("Other", 0.02)]
    degree_choices = [("MS", 0.45), ("PhD", 0.40), ("MEng", 0.10), ("Master", 0.03), ("Masters", 0.02)]
    
    applicants = []
    start_date = date(2024, 1, 1)
    end_date = date(2024, 4, 30)
    
    print("Generating 12,000 realistic applicant records for SQLite...")
    
    for i in range(1, 12001):
        # Random application date
        days_between = (end_date - start_date).days
        random_days = random.randint(0, days_between)
        application_date = start_date + timedelta(days=random_days)
        
        # Realistic GPA (most grad applicants have high GPAs)
        if random.random() < 0.7:
            gpa = round(random.uniform(3.5, 4.0), 2)
        elif random.random() < 0.9:
            gpa = round(random.uniform(3.0, 3.5), 2)
        else:
            gpa = round(random.uniform(2.5, 3.0), 2)
        
        # Realistic GRE scores
        gre_quant = max(130, min(170, int(random.normalvariate(164, 8))))
        gre_verbal = max(130, min(170, int(random.normalvariate(160, 10))))
        gre_aw = max(0, min(6, round(random.normalvariate(4.2, 1.0), 1)))
        
        # Some may not provide all scores
        if random.random() < 0.05:
            gpa = None
        if random.random() < 0.15:
            gre_quant = gre_verbal = gre_aw = None
        
        applicant = (
            i,  # p_id
            random.choice(programs),  # program
            random.choice(comments),  # comments
            application_date.strftime('%Y-%m-%d'),  # date_added
            f'https://www.gradcafe.com/survey/{1000 + i}',  # url
            weighted_choice(status_choices),  # status
            weighted_choice(term_choices),  # term
            weighted_choice(nationality_choices),  # us_or_international
            gpa,  # gpa
            gre_quant,  # gre
            gre_verbal,  # gre_v
            gre_aw,  # gre_aw
            weighted_choice(degree_choices)  # degree
        )
        
        applicants.append(applicant)
        
        if i % 1000 == 0:
            print(f"Generated {i} records...")
    
    return applicants

def create_sqlite_database():
    """Create SQLite database with data"""
    db_path = 'gradcafe.db'
    
    # Remove existing database
    if os.path.exists(db_path):
        os.remove(db_path)
    
    # Connect to SQLite
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create table
    cursor.execute('''
    CREATE TABLE applicants (
        p_id INTEGER PRIMARY KEY,
        program TEXT,
        comments TEXT,
        date_added DATE,
        url TEXT,
        status TEXT,
        term TEXT,
        us_or_international TEXT,
        gpa REAL,
        gre REAL,
        gre_v REAL,
        gre_aw REAL,
        degree TEXT
    )
    ''')
    
    print("Created SQLite database and table")
    
    # Generate and insert data
    applicants = generate_realistic_data()
    
    cursor.executemany('''
    INSERT INTO applicants 
    (p_id, program, comments, date_added, url, status, term, us_or_international, gpa, gre, gre_v, gre_aw, degree)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', applicants)
    
    conn.commit()
    print(f"Inserted {len(applicants)} records into SQLite database")
    
    # Verify data
    cursor.execute("SELECT COUNT(*) FROM applicants")
    total = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM applicants WHERE term = 'Spring 2025'")
    spring_2025 = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM applicants WHERE us_or_international = 'International'")
    international = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM applicants WHERE status = 'Accepted'")
    accepted = cursor.fetchone()[0]
    
    print(f"\nSQLite Database Statistics:")
    print(f"Total applicants: {total}")
    print(f"Spring 2025 applications: {spring_2025}")
    print(f"International students: {international}")
    print(f"Accepted applications: {accepted}")
    
    conn.close()
    print(f"SQLite database saved as: {db_path}")

if __name__ == '__main__':
    create_sqlite_database()