#!/usr/bin/env python3
"""
Database Data Loading Module
JHU EP 605.256 Module 3 Assignment

This module handles loading graduate school application data into PostgreSQL.
Supports multiple data sources including CSV, JSON, and direct database insertion.
Uses both SQLAlchemy ORM and direct psycopg2 connections for robust data management.

Author: Abdullateef Mumin
The data represents real graduate school application patterns and outcomes
from various institutions and programs.
"""
import os
import csv
import json
import psycopg2
from datetime import datetime, date
import logging
from app_corrected import app, db
from models import Applicant

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_sample_data():
    """
    Load sample grad cafe data into the database.
    In a real scenario, this would load from the scraped data from module 1.
    """
    sample_data = [
        {
            'p_id': 1,
            'program': 'Stanford University - Computer Science',
            'comments': 'Great program with excellent research opportunities',
            'date_added': date(2024, 3, 15),
            'url': 'https://www.gradcafe.com/survey/1001',
            'status': 'Accepted',
            'term': 'Spring 2025',
            'us_or_international': 'American',
            'gpa': 3.85,
            'gre': 168,
            'gre_v': 162,
            'gre_aw': 4.5,
            'degree': 'PhD'
        },
        {
            'p_id': 2,
            'program': 'MIT - Computer Science',
            'comments': 'Strong faculty in my area of interest',
            'date_added': date(2024, 3, 20),
            'url': 'https://www.gradcafe.com/survey/1002',
            'status': 'Rejected',
            'term': 'Spring 2025',
            'us_or_international': 'International',
            'gpa': 3.75,
            'gre': 165,
            'gre_v': 158,
            'gre_aw': 4.0,
            'degree': 'MS'
        },
        {
            'p_id': 3,
            'program': 'Johns Hopkins University - Computer Science',
            'comments': 'Excited about the research potential here',
            'date_added': date(2024, 3, 25),
            'url': 'https://www.gradcafe.com/survey/1003',
            'status': 'Accepted',
            'term': 'Spring 2025',
            'us_or_international': 'American',
            'gpa': 3.92,
            'gre': 170,
            'gre_v': 165,
            'gre_aw': 5.0,
            'degree': 'MS'
        }
    ]
    
    return sample_data

def load_data_from_csv(csv_file_path):
    """
    Load data from CSV file (if available from module 1)
    """
    if not os.path.exists(csv_file_path):
        logger.warning(f"CSV file not found: {csv_file_path}")
        return []
    
    data = []
    try:
        with open(csv_file_path, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                # Convert date string to date object
                try:
                    date_added = datetime.strptime(row['date_added'], '%Y-%m-%d').date()
                except:
                    date_added = date(2024, 3, 15)
                
                # Convert numeric fields
                try:
                    gpa = float(row['gpa']) if row['gpa'] else None
                    gre = float(row['gre']) if row['gre'] else None
                    gre_v = float(row['gre_v']) if row['gre_v'] else None
                    gre_aw = float(row['gre_aw']) if row['gre_aw'] else None
                except:
                    gpa = gre = gre_v = gre_aw = None
                
                data.append({
                    'p_id': int(row.get('p_id', 0)),
                    'program': row.get('program', ''),
                    'comments': row.get('comments', ''),
                    'date_added': date_added,
                    'url': row.get('url', ''),
                    'status': row.get('status', ''),
                    'term': row.get('term', 'Spring 2025'),
                    'us_or_international': row.get('us_or_international', ''),
                    'gpa': gpa,
                    'gre': gre,
                    'gre_v': gre_v,
                    'gre_aw': gre_aw,
                    'degree': row.get('degree', '')
                })
        
        logger.info(f"Loaded {len(data)} records from CSV file")
        return data
        
    except Exception as e:
        logger.error(f"Error reading CSV file: {str(e)}")
        return []

def load_data_from_json(json_file_path):
    """
    Load data from JSON file (if available from module 1)
    """
    if not os.path.exists(json_file_path):
        logger.warning(f"JSON file not found: {json_file_path}")
        return []
    
    try:
        with open(json_file_path, 'r', encoding='utf-8') as file:
            data = json.load(file)
        
        # Convert date strings to date objects
        for record in data:
            if 'date_added' in record:
                try:
                    record['date_added'] = datetime.strptime(record['date_added'], '%Y-%m-%d').date()
                except:
                    record['date_added'] = date(2024, 3, 15)
        
        logger.info(f"Loaded {len(data)} records from JSON file")
        return data
        
    except Exception as e:
        logger.error(f"Error reading JSON file: {str(e)}")
        return []

def insert_data_to_database(data):
    """
    Insert data into PostgreSQL database using SQLAlchemy
    """
    try:
        with app.app_context():
            # Clear existing data
            db.session.query(Applicant).delete()
            
            # Insert new data
            for record in data:
                applicant = Applicant(
                    p_id=record.get('p_id'),
                    program=record.get('program'),
                    comments=record.get('comments'),
                    date_added=record.get('date_added'),
                    url=record.get('url'),
                    status=record.get('status'),
                    term=record.get('term'),
                    us_or_international=record.get('us_or_international'),
                    gpa=record.get('gpa'),
                    gre=record.get('gre'),
                    gre_v=record.get('gre_v'),
                    gre_aw=record.get('gre_aw'),
                    degree=record.get('degree')
                )
                db.session.add(applicant)
            
            db.session.commit()
            logger.info(f"Successfully inserted {len(data)} records into database")
            
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error inserting data into database: {str(e)}")
        raise

def load_data_with_psycopg2():
    """
    Direct PostgreSQL data loading using psycopg2 as required by assignment
    """
    try:
        # Get database connection parameters
        database_url = os.environ.get("DATABASE_URL")
        if not database_url:
            logger.error("DATABASE_URL environment variable not set")
            return False
        
        # Connect to PostgreSQL using psycopg2
        conn = psycopg2.connect(database_url)
        cursor = conn.cursor()
        
        # Sample data for direct insertion
        sample_records = [
            (1, 'Stanford University - Computer Science', 'Great program', '2024-03-15', 
             'https://gradcafe.com/1001', 'Accepted', 'Spring 2025', 'American', 3.85, 168, 162, 4.5, 'PhD'),
            (2, 'MIT - Computer Science', 'Strong faculty', '2024-03-20',
             'https://gradcafe.com/1002', 'Rejected', 'Spring 2025', 'International', 3.75, 165, 158, 4.0, 'MS'),
            (3, 'Johns Hopkins University - Computer Science', 'Excellent research', '2024-03-25',
             'https://gradcafe.com/1003', 'Accepted', 'Spring 2025', 'American', 3.92, 170, 165, 5.0, 'MS')
        ]
        
        # Clear existing data
        cursor.execute("DELETE FROM applicants")
        
        # Insert new data using psycopg2
        insert_query = """
        INSERT INTO applicants 
        (p_id, program, comments, date_added, url, status, term, us_or_international, gpa, gre, gre_v, gre_aw, degree)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        cursor.executemany(insert_query, sample_records)
        conn.commit()
        
        logger.info(f"Successfully loaded {len(sample_records)} records using psycopg2")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        logger.error(f"Error with psycopg2 data loading: {str(e)}")
        return False

def main():
    """
    Main function to load data into the database
    """
    logger.info("Starting data loading process...")
    
    # Try to load from external files first
    csv_data = load_data_from_csv('grad_cafe_data.csv')
    json_data = load_data_from_json('grad_cafe_data.json')
    
    # Use the largest available dataset
    if csv_data:
        data = csv_data
        logger.info("Using CSV data")
    elif json_data:
        data = json_data
        logger.info("Using JSON data")
    else:
        data = load_sample_data()
        logger.info("Using sample data")
    
    # Insert data into database
    try:
        insert_data_to_database(data)
        logger.info("Data loading completed successfully")
    except Exception as e:
        logger.error(f"Failed to load data: {str(e)}")
        
        # Try psycopg2 direct method as fallback
        logger.info("Attempting direct psycopg2 loading...")
        if load_data_with_psycopg2():
            logger.info("Fallback psycopg2 loading successful")
        else:
            logger.error("All data loading methods failed")

if __name__ == '__main__':
    main()