import os
import csv
import json
import psycopg2
from datetime import datetime, date
import logging
from app import app, db
from models import Applicant

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_sample_data():
    """
    Load sample grad cafe data into the database.
    In a real scenario, this would load from the scraped data from module 1.
    """
    sample_data = [
        {
            'program': 'Johns Hopkins University - Computer Science',
            'comments': 'Great program, excited to start!',
            'date_added': date(2024, 3, 15),
            'url': 'https://www.gradcafe.com/survey/1234',
            'status': 'Accepted',
            'term': 'Fall 2024',
            'us_or_international': 'American',
            'gpa': 3.8,
            'gre': 165,
            'gre_v': 160,
            'gre_aw': 4.5,
            'degree': 'MS'
        },
        {
            'program': 'Stanford University - Computer Science',
            'comments': 'Competitive program',
            'date_added': date(2024, 2, 20),
            'url': 'https://www.gradcafe.com/survey/1235',
            'status': 'Rejected',
            'term': 'Fall 2024',
            'us_or_international': 'International',
            'gpa': 3.9,
            'gre': 170,
            'gre_v': 155,
            'gre_aw': 4.0,
            'degree': 'PhD'
        },
        {
            'program': 'MIT - Computer Science',
            'comments': 'Dream school!',
            'date_added': date(2024, 1, 10),
            'url': 'https://www.gradcafe.com/survey/1236',
            'status': 'Accepted',
            'term': 'Fall 2024',
            'us_or_international': 'International',
            'gpa': 4.0,
            'gre': 168,
            'gre_v': 165,
            'gre_aw': 5.0,
            'degree': 'PhD'
        },
        {
            'program': 'Carnegie Mellon University - Computer Science',
            'comments': 'Waiting for decision',
            'date_added': date(2024, 3, 1),
            'url': 'https://www.gradcafe.com/survey/1237',
            'status': 'Wait List',
            'term': 'Fall 2024',
            'us_or_international': 'American',
            'gpa': 3.7,
            'gre': 162,
            'gre_v': 158,
            'gre_aw': 4.0,
            'degree': 'MS'
        },
        {
            'program': 'University of California Berkeley - Computer Science',
            'comments': 'Great faculty',
            'date_added': date(2024, 2, 28),
            'url': 'https://www.gradcafe.com/survey/1238',
            'status': 'Accepted',
            'term': 'Fall 2024',
            'us_or_international': 'Other',
            'gpa': 3.85,
            'gre': 166,
            'gre_v': 162,
            'gre_aw': 4.5,
            'degree': 'MS'
        },
        {
            'program': 'Johns Hopkins University - Computer Science',
            'comments': 'Second choice but good program',
            'date_added': date(2024, 3, 5),
            'url': 'https://www.gradcafe.com/survey/1239',
            'status': 'Accepted',
            'term': 'Fall 2024',
            'us_or_international': 'International',
            'gpa': 3.6,
            'gre': 160,
            'gre_v': 155,
            'gre_aw': 3.5,
            'degree': 'MS'
        },
        {
            'program': 'Harvard University - Computer Science',
            'comments': 'Highly selective',
            'date_added': date(2024, 4, 1),
            'url': 'https://www.gradcafe.com/survey/1240',
            'status': 'Rejected',
            'term': 'Fall 2024',
            'us_or_international': 'American',
            'gpa': 3.9,
            'gre': 169,
            'gre_v': 163,
            'gre_aw': 4.5,
            'degree': 'PhD'
        },
        {
            'program': 'Georgia Tech - Computer Science',
            'comments': 'Strong technical program',
            'date_added': date(2024, 2, 15),
            'url': 'https://www.gradcafe.com/survey/1241',
            'status': 'Accepted',
            'term': 'Fall 2024',
            'us_or_international': 'International',
            'gpa': 3.75,
            'gre': 164,
            'gre_v': 157,
            'gre_aw': 4.0,
            'degree': 'MS'
        },
        {
            'program': 'University of Washington - Computer Science',
            'comments': 'Good research opportunities',
            'date_added': date(2024, 3, 20),
            'url': 'https://www.gradcafe.com/survey/1242',
            'status': 'Accepted',
            'term': 'Spring 2024',
            'us_or_international': 'American',
            'gpa': 3.8,
            'gre': 163,
            'gre_v': 159,
            'gre_aw': 4.0,
            'degree': 'MS'
        },
        {
            'program': 'Cornell University - Computer Science',
            'comments': 'Ivy League experience',
            'date_added': date(2024, 1, 25),
            'url': 'https://www.gradcafe.com/survey/1243',
            'status': 'Rejected',
            'term': 'Fall 2024',
            'us_or_international': 'International',
            'gpa': 3.95,
            'gre': 167,
            'gre_v': 161,
            'gre_aw': 4.5,
            'degree': 'PhD'
        }
    ]
    
    return sample_data

def load_data_from_csv(csv_file_path):
    """
    Load data from CSV file (if available from module 1)
    """
    data = []
    try:
        with open(csv_file_path, 'r', newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                # Convert date string to date object
                if row.get('date_added'):
                    try:
                        row['date_added'] = datetime.strptime(row['date_added'], '%Y-%m-%d').date()
                    except ValueError:
                        row['date_added'] = None
                
                # Convert numeric fields
                for field in ['gpa', 'gre', 'gre_v', 'gre_aw']:
                    if row.get(field):
                        try:
                            row[field] = float(row[field])
                        except ValueError:
                            row[field] = None
                
                data.append(row)
        logger.info(f"Loaded {len(data)} records from CSV file")
    except FileNotFoundError:
        logger.warning(f"CSV file {csv_file_path} not found")
    except Exception as e:
        logger.error(f"Error loading CSV file: {str(e)}")
    
    return data

def load_data_from_json(json_file_path):
    """
    Load data from JSON file (if available from module 1)
    """
    data = []
    try:
        with open(json_file_path, 'r', encoding='utf-8') as jsonfile:
            data = json.load(jsonfile)
            
        # Process the data similar to CSV
        for row in data:
            if row.get('date_added'):
                try:
                    row['date_added'] = datetime.strptime(row['date_added'], '%Y-%m-%d').date()
                except ValueError:
                    row['date_added'] = None
            
            for field in ['gpa', 'gre', 'gre_v', 'gre_aw']:
                if row.get(field):
                    try:
                        row[field] = float(row[field])
                    except ValueError:
                        row[field] = None
        
        logger.info(f"Loaded {len(data)} records from JSON file")
    except FileNotFoundError:
        logger.warning(f"JSON file {json_file_path} not found")
    except Exception as e:
        logger.error(f"Error loading JSON file: {str(e)}")
    
    return data

def insert_data_to_database(data):
    """
    Insert data into PostgreSQL database using SQLAlchemy
    """
    try:
        with app.app_context():
            # Clear existing data
            Applicant.query.delete()
            db.session.commit()
            
            # Insert new data
            for i, record in enumerate(data, 1):
                applicant = Applicant(
                    p_id=i,
                    program=record.get('program'),
                    comments=record.get('comments'),
                    date_added=record.get('date_added'),
                    url=record.get('url'),
                    status=record.get('status'),
                    term=record.get('term'),
                    us_or_international=record.get('us_or_international'),
                    gpa=record.get('gpa'),
                    gre=record.get('gre'),
                    gre_v=record.get('gre_v'),
                    gre_aw=record.get('gre_aw'),
                    degree=record.get('degree')
                )
                db.session.add(applicant)
            
            db.session.commit()
            logger.info(f"Successfully inserted {len(data)} records into database")
            
    except Exception as e:
        logger.error(f"Error inserting data into database: {str(e)}")
        db.session.rollback()
        raise

def main():
    """
    Main function to load data into the database
    """
    logger.info("Starting data loading process...")
    
    # Try to load from different sources
    data = []
    
    # First try to load from CSV (from module 1)
    csv_data = load_data_from_csv('grad_cafe_data.csv')
    if csv_data:
        data = csv_data
    else:
        # Try JSON
        json_data = load_data_from_json('grad_cafe_data.json')
        if json_data:
            data = json_data
        else:
            # Use sample data if no scraped data available
            logger.info("No scraped data found, using sample data for demonstration")
            data = load_sample_data()
    
    if data:
        insert_data_to_database(data)
        logger.info("Data loading completed successfully!")
    else:
        logger.error("No data to load!")

if __name__ == '__main__':
    main()
