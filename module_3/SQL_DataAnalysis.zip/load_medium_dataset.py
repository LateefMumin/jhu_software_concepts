#!/usr/bin/env python3
"""
Load a substantial dataset of 1,000+ realistic applicant records
"""
import random
from datetime import date, timedelta
from app import app, db
from models import Applicant

# Realistic university programs (expanded list)
PROGRAMS = [
    "Stanford University - Computer Science", "MIT - Computer Science", "Carnegie Mellon University - Computer Science",
    "University of California Berkeley - Computer Science", "Harvard University - Computer Science", 
    "Princeton University - Computer Science", "Yale University - Computer Science", "Columbia University - Computer Science",
    "Cornell University - Computer Science", "University of Pennsylvania - Computer Science",
    "Johns Hopkins University - Computer Science", "Northwestern University - Computer Science",
    "Duke University - Computer Science", "University of Chicago - Computer Science", "Rice University - Computer Science",
    "Vanderbilt University - Computer Science", "Georgetown University - Computer Science",
    "University of Southern California - Computer Science", "University of California Los Angeles - Computer Science",
    "University of California San Diego - Computer Science", "Georgia Institute of Technology - Computer Science",
    "University of Illinois Urbana-Champaign - Computer Science", "University of Washington - Computer Science",
    "University of Texas Austin - Computer Science", "University of Michigan Ann Arbor - Computer Science",
    "Purdue University - Computer Science", "Ohio State University - Computer Science",
    "Pennsylvania State University - Computer Science", "University of Wisconsin Madison - Computer Science",
    "University of Minnesota - Computer Science", "University of Maryland College Park - Computer Science",
    "Virginia Tech - Computer Science", "North Carolina State University - Computer Science",
    "Arizona State University - Computer Science", "University of Colorado Boulder - Computer Science",
    "Boston University - Computer Science", "Northeastern University - Computer Science",
    "University of Rochester - Computer Science", "Case Western Reserve University - Computer Science",
    "Rensselaer Polytechnic Institute - Computer Science", "Stevens Institute of Technology - Computer Science",
    "New York University - Computer Science", "University of California Irvine - Computer Science",
    "Stanford University - Data Science", "MIT - Data Science", "Harvard University - Data Science",
    "University of California Berkeley - Data Science", "Carnegie Mellon University - Data Science",
    "MIT - Electrical Engineering", "Stanford University - Electrical Engineering",
    "University of California Berkeley - Electrical Engineering", "Georgia Institute of Technology - Electrical Engineering",
    "Harvard University - Mathematics", "MIT - Mathematics", "Princeton University - Mathematics",
    "Stanford University - Statistics", "University of California Berkeley - Statistics"
]

def weighted_choice(choices):
    """Select from weighted choices"""
    total = sum(weight for choice, weight in choices)
    r = random.uniform(0, total)
    upto = 0
    for choice, weight in choices:
        if upto + weight >= r:
            return choice
        upto += weight
    return choices[-1][0]

def generate_realistic_data():
    """Generate realistic applicant data"""
    # Weighted distributions
    status_choices = [("Accepted", 0.35), ("Rejected", 0.55), ("Wait List", 0.08), ("Interview", 0.02)]
    term_choices = [("Spring 2025", 0.85), ("Fall 2024", 0.10), ("Spring 2024", 0.03), ("Fall 2025", 0.02)]
    nationality_choices = [("American", 0.48), ("International", 0.50), ("Other", 0.02)]
    degree_choices = [("MS", 0.45), ("PhD", 0.40), ("MEng", 0.10), ("Master", 0.03), ("Masters", 0.02)]
    
    comments_list = [
        "Great program with excellent research opportunities", "Strong faculty in my area of interest",
        "Excited about the research potential here", "This is my dream school", "Excellent fit for my research interests",
        "Strong program reputation", "Great location and facilities", "Looking forward to the opportunity",
        "Perfect match for my career goals", "Impressed by the faculty research", "Hoping for funding opportunities",
        "Strong alumni network", "Excellent research facilities", "Great program curriculum",
        "Perfect fit for my background", "Excited about potential collaborations", "Strong industry connections",
        "Great campus and environment", "Hoping for a positive outcome", "This program aligns with my goals"
    ]
    
    applicants = []
    start_date = date(2024, 1, 1)
    end_date = date(2024, 4, 30)
    
    print("Generating 12,000 realistic applicant records...")
    
    for i in range(1, 12001):  # Generate 12,000 records
        # Random application date
        days_between = (end_date - start_date).days
        random_days = random.randint(0, days_between)
        application_date = start_date + timedelta(days=random_days)
        
        # Realistic GPA generation (most grad applicants have high GPAs)
        if random.random() < 0.7:  # 70% have high GPAs
            gpa = round(random.uniform(3.5, 4.0), 2)
        elif random.random() < 0.9:  # 20% have medium GPAs
            gpa = round(random.uniform(3.0, 3.5), 2)
        else:  # 10% have lower GPAs
            gpa = round(random.uniform(2.5, 3.0), 2)
        
        # Realistic GRE scores (higher averages for competitive programs)
        gre_quant = max(130, min(170, int(random.normalvariate(164, 8))))
        gre_verbal = max(130, min(170, int(random.normalvariate(160, 10))))
        gre_aw = max(0, min(6, round(random.normalvariate(4.2, 1.0), 1)))
        
        # Some applicants may not provide all scores
        if random.random() < 0.05:  # 5% don't provide GPA
            gpa = None
        if random.random() < 0.15:  # 15% don't provide GRE
            gre_quant = gre_verbal = gre_aw = None
        
        applicant_data = {
            'p_id': i,
            'program': random.choice(PROGRAMS),
            'comments': random.choice(comments_list),
            'date_added': application_date,
            'url': f'https://www.gradcafe.com/survey/{1000 + i}',
            'status': weighted_choice(status_choices),
            'term': weighted_choice(term_choices),
            'us_or_international': weighted_choice(nationality_choices),
            'gpa': gpa,
            'gre': gre_quant,
            'gre_v': gre_verbal,
            'gre_aw': gre_aw,
            'degree': weighted_choice(degree_choices)
        }
        
        applicants.append(applicant_data)
        
        if i % 1000 == 0:
            print(f"Generated {i} records...")
    
    return applicants

def load_to_database(applicants):
    """Load applicants to database"""
    with app.app_context():
        try:
            # Clear existing data
            Applicant.query.delete()
            db.session.commit()
            print("Cleared existing data")
            
            # Insert new data in larger batches for efficiency
            batch_size = 500
            total_inserted = 0
            
            for i in range(0, len(applicants), batch_size):
                batch = applicants[i:i + batch_size]
                
                for data in batch:
                    applicant = Applicant(**data)
                    db.session.add(applicant)
                
                db.session.commit()
                total_inserted += len(batch)
                print(f"Inserted {total_inserted} records...")
            
            print(f"Successfully loaded {total_inserted} applicant records")
            
            # Verify data
            total_count = Applicant.query.count()
            spring_2025_count = Applicant.query.filter(Applicant.term == 'Spring 2025').count()
            international_count = Applicant.query.filter(Applicant.us_or_international == 'International').count()
            accepted_count = Applicant.query.filter(Applicant.status == 'Accepted').count()
            
            print(f"\nDataset Statistics:")
            print(f"Total applicants: {total_count}")
            print(f"Spring 2025 applications: {spring_2025_count}")
            print(f"International students: {international_count}")
            print(f"Accepted applications: {accepted_count}")
            
        except Exception as e:
            print(f"Error loading data: {str(e)}")
            db.session.rollback()
            raise

def main():
    """Generate and load substantial dataset"""
    applicants = generate_realistic_data()
    load_to_database(applicants)

if __name__ == '__main__':
    main()