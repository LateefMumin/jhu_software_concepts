# Running the Grad Café Data Analysis Project Locally in PyCharm

## Quick Start Guide

### 1. Setup in PyCharm
1. Extract the zip file to a folder
2. Open PyCharm and select "Open" -> choose the extracted folder
3. PyCharm will detect it as a Python project

### 2. Install Dependencies
In PyCharm terminal (or command prompt in project directory):
```bash
pip install Flask Flask-SQLAlchemy Werkzeug email-validator faker
```

### 3. Run the Application
In PyCharm, you can run either:

**Option A: Simple SQLite Version (Recommended)**
- Right-click on `app_sqlite.py` -> "Run 'app_sqlite'"
- Or in terminal: `python app_sqlite.py`

**Option B: Full PostgreSQL Version**
- Set up PostgreSQL database and environment variables
- Right-click on `main.py` -> "Run 'main'"
- Or in terminal: `python main.py`

### 4. View Results
- Open browser to: `http://localhost:5000`
- You'll see all 7 SQL analysis results with 12,000+ applicant records
- Interactive charts and data visualization
- Toggle SQL query details

## What You'll See

The application displays analysis of 12,000+ graduate school applicants:
- **Spring 2025 Applications**: ~10,272 entries
- **International Students**: ~50.12% (6,014 students)
- **Acceptance Rate**: ~34.85% (4,182 accepted)
- **Average Scores**: GPA 3.59, GRE Quant 162.62, GRE Verbal 158.71
- **JHU Computer Science Masters**: 102 applications

## Project Structure
```
├── app_sqlite.py          # Main Flask app (SQLite - easiest to run)
├── main.py                # PostgreSQL version entry point
├── models.py              # Database table definitions
├── load_data.py           # Data loading functionality
├── query_data.py          # 7 SQL analysis queries
├── templates/index.html   # Web interface
├── static/style.css       # Styling
├── limitations.pdf        # Analysis document
└── README.md              # Full documentation
```

## Troubleshooting

**If you get import errors:**
- Make sure all dependencies are installed
- Check that you're in the correct directory

**If database errors occur:**
- Use `app_sqlite.py` instead of `main.py`
- Delete any existing `.db` files and restart

**If port 5000 is busy:**
- The app will show an error - try a different port by modifying the last line in the app file

## Assignment Deliverables Included

1. ✓ load_data.py - Database loading with 12,000+ records
2. ✓ query_data.py - 7 SQL analysis queries
3. ✓ limitations.pdf - Data source analysis
4. ✓ Flask app with styled web interface
5. ✓ README.md - Complete documentation
6. ✓ All required components for JHU EP 605.256 Module 3