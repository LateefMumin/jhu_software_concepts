import os
import logging
from flask import Flask, render_template, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix

# Set up logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback-secret-key-for-development")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "postgresql://localhost/gradcafe")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

@app.route('/')
def index():
    """Main page displaying all analysis results"""
    try:
        from query_data import get_all_analysis_results
        results = get_all_analysis_results()
        return render_template('index.html', results=results)
    except Exception as e:
        app.logger.error(f"Error getting analysis results: {str(e)}")
        return render_template('index.html', error=str(e))

@app.route('/api/results')
def api_results():
    """API endpoint for getting results as JSON"""
    try:
        from query_data import get_all_analysis_results
        results = get_all_analysis_results()
        return jsonify(results)
    except Exception as e:
        app.logger.error(f"Error getting API results: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        # Import models to ensure tables are created
        import models
        db.create_all()
        
        # Load sample data if tables are empty
        from models import Applicant
        if Applicant.query.count() == 0:
            from load_data import main as load_data_main
            load_data_main()
    
    app.run(host='0.0.0.0', port=5000, debug=True)
