#!/usr/bin/env python3
"""
Graduate School Data Analysis Web Application
JHU EP 605.256 Module 3 Assignment - SQL Data Analysis

This Flask application analyzes graduate school admission data from grad cafe,
implementing PostgreSQL database operations and presenting analytical insights
through a responsive web interface.

Author: Abdullateef Mumin
Course: EP 605.256 - Modern Software Concepts in Python
"""
import os
from flask import Flask, render_template, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET") or "dev-secret-key-change-in-production"

# Configure PostgreSQL database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL") or "postgresql://user:password@localhost:5432/gradcafe"
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the extension
db.init_app(app)

@app.route('/')
def index():
    """Main page displaying all analysis results"""
    try:
        from query_data import get_all_analysis_results
        results = get_all_analysis_results()
        return render_template('index.html', results=results)
    except Exception as e:
        app.logger.error(f"Error getting analysis results: {str(e)}")
        return render_template('index.html', error=str(e))

@app.route('/api/results')
def api_results():
    """API endpoint for getting results as JSON"""
    try:
        from query_data import get_all_analysis_results
        results = get_all_analysis_results()
        return jsonify(results)
    except Exception as e:
        app.logger.error(f"Error getting API results: {str(e)}")
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        # Import models to ensure tables are created
        import models
        db.create_all()
        
        # Load sample data if tables are empty
        try:
            from models import Applicant
            if Applicant.query.count() == 0:
                from load_data import main as load_data_main
                load_data_main()
        except Exception as e:
            app.logger.warning(f"Could not load initial data: {e}")
    
    app.run(host='0.0.0.0', port=5000, debug=True)