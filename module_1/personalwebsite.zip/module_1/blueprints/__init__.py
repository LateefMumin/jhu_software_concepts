"""
Blueprints package initialization.
This package contains all the blueprint modules for organizing routes.
"""
