"""
Main module import for the Flask application.
This allows the app to be imported and run properly.
"""

from app import app  # noqa: F401
import routes  # noqa: F401
